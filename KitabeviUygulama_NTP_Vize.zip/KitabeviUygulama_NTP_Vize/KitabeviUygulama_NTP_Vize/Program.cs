﻿using System;
using System.IO;

namespace KitabeviUygulama_NTP_Vize
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("1- Kitap Ekle\n2- Kitabevi Kitaplarını Listele"); // Menü seçimi için 2 adet seçim sunduk kullanıcıya
                int secim = int.Parse(Console.ReadLine()); //kulllanıcının gireceği rakamı istedik 
                switch (secim) // seçim sonucu ne olması gerektiğini switch casele belirledik
                {
                    case 1:
                        Kitap.ListeKayit(); 
                        break;
                    case 2:
                        Kitap.ListeGetir();

                        break;
                    default:
                        Console.WriteLine("1 ya da 2'yi tuşlayınız");
                        break;
                }
            }

            catch (System.OutOfMemoryException)
            {
                Console.WriteLine("Programın çalışması için yeterli bellek kalmadı!");
            }
                Console.ReadKey();
            
        }
    }


    class Kitap // kitap classı oluşturduk. Kitap bilgilerinin girişi ve listesini almak için burası kullanılacak
    {
        public Kitap() 
        {

        }

        public string ktpadi { get; set; } // kapsülleme-encapsulation            
        public string yazaradi { get; set; }// kapsülleme-encapsulation
        public string ktpturu { get; set; }     // kapsülleme-encapsulation   
        public DateTime basimyili { get; set; }// kapsülleme-encapsulation

        public Kitap(string ktpadi, string yazaradi, string ktpturu, DateTime basimyili) 
        {
            this.ktpadi = ktpadi;
            this.yazaradi = yazaradi;
            this.ktpturu = ktpturu;
            this.basimyili = basimyili;

        }

        public static void ListeKayit() // liste kayıt için metod oluşturduk
        {
            Console.WriteLine("Kitap Sayısı Giriniz: "); // kaç adet kitap istendiğini sorduk
            int sayi = int.Parse(Console.ReadLine()); // cevap aldık

            Kitap kitap = new Kitap(); //kitap nesnesi oluşturduk

            for (int i = 0; i < sayi; i++) //kaç adet kitap istendiğine göre kitap bilgilerinin  döngüsü yapıldı
            {
                Console.WriteLine("Kitabın Adı: ");
                kitap.ktpadi = Console.ReadLine();
                Console.WriteLine("Kitap Yazarı: ");
                kitap.yazaradi = Console.ReadLine();
                Console.WriteLine("Kitap Türü: ");
                kitap.ktpturu = Console.ReadLine();
                Console.WriteLine("Basım Tarihi: ");
                kitap.basimyili = DateTime.Parse(Console.ReadLine());
                Kitap[] kitapdizi = new Kitap[sayi];
                kitapdizi[i] = kitap;


                string dosya_yolu = @"G:\kitap_liste.txt"; // liste oluşturuldu ve içine girilen bilgiler kaydedildi
               
                FileStream fs = new FileStream(dosya_yolu, FileMode.OpenOrCreate, FileAccess.Write);
               
                StreamWriter sw = new StreamWriter(fs);
                for (int j = 0; j < sayi; j++) // kaç adet kitap varsa ona göre listeleme işlemi yapıldı
                {
                    sw.WriteLine($"Kitabın Adı: {kitap.ktpadi}, Kitap Yazarı: {kitap.yazaradi}, Kitap Türü: {kitap.ktpturu}, Basım Yılı: {kitap.basimyili}\r\n");
                }
               
                
                sw.Flush();
               
                sw.Close();
                fs.Close();

            }
        }

        public static void ListeGetir() // listegetir metoduyla oluşturduğumuz listenin görüntülenmesini sağladık
        {
            string dosya_yolu = @"G:\kitap_liste.txt";
            
            FileStream fs = new FileStream(dosya_yolu, FileMode.Open, FileAccess.Read);
         
            StreamReader sw = new StreamReader(fs);
            
            string yazi = sw.ReadLine();
            while (yazi != null)
            {
                Console.WriteLine(yazi);
                yazi = sw.ReadLine();
            }
           
            sw.Close();
            fs.Close();
        }
    }
}
 